/**
 * @description 默认常量配置
 * @author xiaokyo
 */

export default {
    focus: true,
    height: 300,
    placeholder: '请输入正文',
    zIndexFullScreen: 10002,
    showFullScreen: true,
}
