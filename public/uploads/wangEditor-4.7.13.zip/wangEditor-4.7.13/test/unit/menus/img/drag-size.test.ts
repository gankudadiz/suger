/**
 * @description Img menu bind-event drag-size
 * @author luochao
 */

describe('Img menu bind-eveent drag-size', () => {
    test('绑定drag-size事件', () => {
        expect(true).toBeTruthy()
    })
})
