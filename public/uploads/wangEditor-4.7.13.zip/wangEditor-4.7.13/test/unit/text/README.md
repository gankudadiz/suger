# editor.txt 测试

- API 已完成
- event hooks 暂时没找到测试的方法，待定
